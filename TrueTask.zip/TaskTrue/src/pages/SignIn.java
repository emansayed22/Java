package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SignIn {
	WebDriver driver;
	
	public SignIn(WebDriver driver){
		this.driver=driver;
	}

	public WebElement EmailField()
	{
		return driver.findElement(By.cssSelector("input[aria-label=\"Email or phone\"]"));
		
	}
	
	public WebElement NextBtn()
	{
		return driver.findElement(By.xpath("//button[@jscontroller=\"soHxf\" and @jsname=\"LgbsSe\"]"));
		
	}
	
	public WebElement error_msg()
	{
		return driver.findElement(By.xpath("//div[@jsname=\"B34EJ\"]/div[@class=\"o6cuMc\"]"));
		
	}
	public WebElement forgot_email()
	{
		return driver.findElement(By.xpath("//button[@jsname=\"Cuz2Ue\"]"));
		
	}
}


