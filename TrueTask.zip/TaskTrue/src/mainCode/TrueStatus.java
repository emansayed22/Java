package mainCode;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.HomePage;
import pages.SignIn;



public class TrueStatus {
	static WebDriver driver;
	
public static void main(String[] args) throws InterruptedException {
		
		Launch_Browser();
		Login_With_Invalid_Email();
		Verify_Forgot_Email_URL();
		Google_Search();
		Close_Driver();
	}

//Before Test
public static void Launch_Browser()
{
	String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
	System.setProperty("webdriver.chrome.driver", chromePath);
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.navigate().to("https://www.google.com/?hl=ar");
	driver.findElement(By.partialLinkText("Eng")).click();
}


//Test Case 1: Login without using email field
public static void Login_With_Invalid_Email() throws InterruptedException


{
	HomePage home = new HomePage(driver);
	home.signInBtn().click();
	SignIn sign = new SignIn(driver);
	sign.EmailField().sendKeys("asw");
     sign.NextBtn().click();
	Thread.sleep(2000);

	String actualResult;
	actualResult= sign.error_msg().getText();
	System.out.println(actualResult);
	System.out.println(!contains("Couldn't find your Google Account"));

}

private static boolean contains(String actualResult) {
	// TODO Auto-generated method stub
	return false;
}

//Test Case 2: Get forget email url
public static void Verify_Forgot_Email_URL()
{
	SignIn sign = new SignIn(driver);
	sign.forgot_email().click();

	
	String actualResult;
	actualResult = driver.getCurrentUrl();
	
	System.out.println(actualResult);
	System.out.println(actualResult.contains("/signin/v2/usernamerecovery"));

}

//Test Case 3: Google Search
public static void Google_Search() {
	driver.navigate().to("https://www.google.com/?hl=eng");
	
	HomePage home = new HomePage(driver);
	home.SearchField().click();
	home.SearchField().sendKeys("selenium");
	home.SearchField().sendKeys(Keys.ENTER);
	System.out.println(driver.findElement(By.id("result-stats")).getText());
	System.out.println(driver.findElement(By.id("result-stats")).getText().contains("results"));
	
}


//After Test
public static void Close_Driver()
{
	driver.quit();

}

}
